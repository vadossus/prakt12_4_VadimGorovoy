﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            button2.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {    
            try
            {
                string name_car = textBox1.Text;
                int Count_benzin = (int)numericUpDown1.Value;
                int Capacity = (int)numericUpDown3.Value;
                double Rasxod_benzin = (double)numericUpDown2.Value;
                int Probeg = Convert.ToInt32(textBox2.Text);

                Car car = new Car(Capacity, Count_benzin, Rasxod_benzin, Probeg);

                listBox1.Items.Add(name_car + $" {car.Car_Info()}");

                if (listBox1.Items.Count >= 10)
                {
                    MessageBox.Show("В листе не может быть 10 автомобилей");
                    button2.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Появилась ошибка: {ex.Message}");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int Count_benzin = (int)numericUpDown1.Value;
                int Capacity = (int)numericUpDown3.Value;
                double Rasxod_benzin = (double)numericUpDown2.Value;
                int Probeg = Convert.ToInt32(textBox2.Text);

                Car car = new Car(Capacity, Count_benzin, Rasxod_benzin, Probeg);

                int benzNeed = Convert.ToInt32(textBox3.Text);
                int benzNotAdded = car.Refuel(benzNeed);
                car.UpdateCarInfo();
                MessageBox.Show($"Не добавлено {benzNotAdded} л бензина", "Информация о заправке");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Появилась ошибка: {ex.Message}");
            }
        }


        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                int Count_benzin = (int)numericUpDown1.Value;
                int Capacity = (int)numericUpDown3.Value;
                double Rasxod_benzin = (double)numericUpDown2.Value;
                int Probeg = Convert.ToInt32(textBox2.Text);

                Car car = new Car(Capacity, Count_benzin, Rasxod_benzin, Probeg);

                bool needRefuel = car.NeedRefuel();
                string message = needRefuel ? "Нужно заправиться!" : "Заправка не требуется";
                MessageBox.Show(message, "Проверка необходимости заправки");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Появилась ошибка: {ex.Message}");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                int Count_benzin = (int)numericUpDown1.Value;
                int Capacity = (int)numericUpDown3.Value;
                double Rasxod_benzin = (double)numericUpDown2.Value;
                int Probeg = Convert.ToInt32(textBox2.Text);

                Car car = new Car(Capacity, Count_benzin, Rasxod_benzin, Probeg);

                int km = Convert.ToInt32(textBox4.Text);
                string driveInfo = car.Drive(km);
                car.UpdateCarInfo();
                if (!string.IsNullOrEmpty(driveInfo))
                {
                    MessageBox.Show(driveInfo, "Информация о поездке");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Появилась ошибка: {ex.Message}");
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


        }
    }
}
