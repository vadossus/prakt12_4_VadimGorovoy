﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    internal class Car
    {
        public int Capacity { get; set; }
        public int Count_benzin { get; set; }
        public double Rasxod_benzin { get; set; }
        public int Probeg { get; set; }


        public Car(int capacity, int count_benzin, double rasxod_benzin, int probeg)
        {
            Capacity = capacity;
            Count_benzin = count_benzin;
            Rasxod_benzin = rasxod_benzin;
            Probeg = probeg;
        }

        public string Car_Info()
        {
            return $"Объем бака: {Capacity} л, Количество бензина в баке: {Count_benzin} л, Расход бензина: {Rasxod_benzin} л/100км, Пробег: {Probeg} км";
        }

        public int Refuel(int benz_need)
        {
            int benzina_ne_dobavleno = 0;
            if (Count_benzin + benz_need <= Capacity)
            {
                Count_benzin += benz_need;
            }
            else
            {
                benzina_ne_dobavleno = Capacity - Count_benzin;
                Count_benzin = Capacity;
            }
            return benzina_ne_dobavleno;
        }

        public string Drive(int kilometer)
        {
            double benzin_need = kilometer * Rasxod_benzin / 100;
            if (benzin_need <= Count_benzin)
            {
                Count_benzin -= (int)benzin_need;
                Probeg += kilometer;
                if (Probeg % 1000 == 0)
                {
                    Rasxod_benzin += 0.1;
                    return $"Пробег превысил {Probeg} км. Расход увеличен до {Rasxod_benzin} л/100км";
                }
                return "";
            }
            else
            {
                int km_not_reached = (int)(benzin_need * 100 / Rasxod_benzin);
                return $"Не хватило бензина, проехали только {km_not_reached} км";
            }
        }

        public bool NeedRefuel()
        {
            double percentRemaining = (double)Count_benzin / Capacity * 100;
            return percentRemaining <= 10;
        }

        public void UpdateCarInfo()
        {
            MessageBox.Show($"Текущий запас топлива: {Count_benzin} л, Пробег: {Probeg} км, Расход топлива: {Rasxod_benzin} л/100 км");
        }

    }   
}
